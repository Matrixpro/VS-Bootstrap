<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="hero-shadow">
            <img src="<?php echo e(Vite::asset('resources/images/newyork1920.jpg')); ?>"  class="img-fluid hero-image">
        </div>
    </div>
    <div class="row mt-5 mb-3">
        <div class="col text-center">
            <h1 class="fw-semibold">New Homes For Sale in New York</h1>
            <h3 class="mb-4 text-secondary">Find Your Dream Home In Beautiful New York City</h3>
            <p class="text-muted">
                <?php echo e($lipsum->words(64)); ?>

            </p>
        </div>
    </div>
    <div class="form">
        <div class="row mb-4">
            <div class="col-lg-6">
            </div>
            <div class="col-lg-3">
                <select class="form-select filter_select mb-2">
                    <option value="filter_location-reset">Location</option>
                    <?php $__currentLoopData = $locations_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="filter_location-<?php echo e($key); ?>" <?php echo e($key == cache('filter_location') ? 'selected' : ''); ?>><?php echo e($location); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-lg-3">
                <select class="form-select filter_select mb-2">
                    <option value="sort_price-DESC" <?php echo e('DESC' == cache('sort_price') ? 'selected' : ''); ?>>Price: High to Low</option>
                    <option value="sort_price-ASC" <?php echo e('ASC' == cache('sort_price') ? 'selected' : ''); ?>>Price: Low to High</option>
                    <option value="sort_sqft-DESC" <?php echo e('DESC' == cache('sort_sqft') ? 'selected' : ''); ?>>Sq ft: High to Low</option>
                    <option value="sort_sqft-ASC" <?php echo e('ASC' == cache('sort_sqft') ? 'selected' : ''); ?>>Sq ft: Low to High</option>
                </select>
            </div>
        </div>
    </div>
    <div id="locations_grid_container">
        <?php echo $__env->make('locations_grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\dev_matrix\vs-bootstrap\resources\views/home.blade.php ENDPATH**/ ?>