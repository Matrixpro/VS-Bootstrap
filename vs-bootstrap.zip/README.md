# Boostrap vs Tailwind

This is the boostrap project.

Setup:

- Setup your environment w/ local domain, etc.
- Update your .env with database creds and local domain
- CL: composer install
- CL: npm install
- CL: php artisan migrate
- CL: npm run dev
